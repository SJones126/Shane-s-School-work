import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import account.BankAccount;

public class BankAccountTest {
  private BankAccount b1;
  private BankAccount b2;

  @Before
  public void setUp() throws Exception {
    b1 = new BankAccount();
    b2 = new BankAccount(900);
  }
  
  @Test
  public void testBankAccount() {
    double actual = b1.getBalance();
    assertEquals(75,actual,0);
  }
  
  @Test
  public void testBankAccountInitialBalance() {
    double initialBalance = 100.0;
    b2 = new BankAccount(initialBalance);
    double actual = b2.getBalance();
    assertEquals(100.0,actual,0);
  }
  
  @Test
  public void testGetBalance() {
    assertEquals(75.0,b1.getBalance(),0);
  }
  
  @Test
  public void testIsPremiumAccount() {
    assertTrue(b2.isPremiumAccount());
    assertFalse(b1.isPremiumAccount());
  }
  
  @Test
  public void testDeposit()throws InsufficientFundsException, AccountOverdrawnException {
    //deposit money into the accounts
    b1.deposit(100);
    b2.deposit(100);
    
    //check for correct output
    assertEquals(175,b1.getBalance(),0);
    assertEquals(1000,b2.getBalance(),0);
  }

  @Test
  public void testWithdraw()throws InsufficientFundsException, AccountOverdrawnException{
    //withdraws amounts out of the accounts
    b1.withdraw(30);
    b2.withdraw(100);
    //check for correct output
    assertEquals(45,b1.getBalance(),0);
    assertEquals(800,b2.getBalance(),0);
  }
  @Test(expected = InsufficientFundsException.class)
  public void testInsufficientException() throws InsufficientFundsException, AccountOverdrawnException{
	  
  }
  
  @Test
  public void testTransfer()throws InsufficientFundsException, AccountOverdrawnException {
    b1.transfer(15, b2);
    assertEquals(915,b2.getBalance(),0);
    assertEquals(60,b1.getBalance(),0);
  }
 
  @After
  public void tearDown() throws Exception {
    b1 = null;
    b2 = null;
  }
}